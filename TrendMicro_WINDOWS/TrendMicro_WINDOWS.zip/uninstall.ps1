echo "$(Get-Date -format T) - DSA Uninstalled Finished"
echo "msiexec /x <package name including extension> /quiet"


